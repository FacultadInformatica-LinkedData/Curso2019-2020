package eventosService;


import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.jena.riot.RDFDataMgr;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.jena.graph.Triple ;
import org.apache.jena.riot.lang.PipedRDFIterator;
import org.apache.jena.riot.lang.PipedRDFStream;
import org.apache.jena.riot.lang.PipedTriplesStream;

import eventosDts.Evento;


public class EventoService {

	public static void main(String[] args) {
		
		
       
        PipedRDFIterator<Triple> iter = new PipedRDFIterator<>();
        final PipedRDFStream<Triple> inputStream = new PipedTriplesStream(iter);

        // PipedRDFStream and PipedRDFIterator need to be on different threads
        ExecutorService executor = Executors.newSingleThreadExecutor();

        Runnable parser = new Runnable() {

            @Override
            public void run() {
                // llamamos al proceso que lee el .ttl que está en resources
                RDFDataMgr.parse(inputStream, "resources/EventosMadridRDF.ttl");
            }
        };

        // Start the parser on another thread
        executor.submit(parser);

        Evento evento = new Evento();
        List<Evento> eventos=new ArrayList<Evento>();
        
        while (iter.hasNext()) {
            Triple next = iter.next();
            // haz lo que quieras con el triplete
           /*System.out.println("Subject:  "+next.getSubject());
            System.out.println("Object:  "+next.getObject());
            System.out.println("Predicate:  "+next.getPredicate().getLocalName());
            System.out.println("\n");*/
            
            if(next.getPredicate().getLocalName().equals("type")) {
            	continue;
            }else {
            	//si entra aqui empieza un nuevo evento y crea el objeto
            	if(next.getPredicate().getLocalName().equals("featuresEvent")) {
            		evento=new Evento();
            	}
            	if(next.getPredicate().getLocalName().equals("hasName")) {
            		evento.setNombre(next.getObject().toString());
            		
            	}else if(next.getPredicate().getLocalName().equals("hasPrice")) {
            		String precio=encuentraPrecio(next.getObject().toString());
            		System.out.println("precio es : "+precio);
            		System.out.println("precio es : "+precio.toString());
            		evento.setPrecio(Double.parseDouble(precio));
            		
            	}else if(next.getPredicate().getLocalName().equals("hasLatitude")) {
            		String latitud=next.getObject().toString().substring(1, next.getObject().toString().length()-1);
            		evento.setLatitud(Double.parseDouble(latitud));
            		
            	}else if(next.getPredicate().getLocalName().equals("hasLongitude")) {
            		String longitud=next.getObject().toString().substring(1, next.getObject().toString().length()-1);
            		evento.setLongitud(Double.parseDouble(longitud));
            		
            	}else if(next.getPredicate().getLocalName().equals("hasInstallation")) {
            		evento.setLugar(next.getObject().toString());
            		
            	}else if(next.getPredicate().getLocalName().equals("hasId")) {
            		String id=next.getObject().toString();
            		id=id.substring(1, id.length()-1);
            		evento.setId(Integer.parseInt(id));
            		
            		//añadimos a lista 
            		eventos.add(evento);
            	}
            	
            }
        }
		
        //imprime lista de eventos
        for(Evento obj: eventos) {
				System.out.println("\n Nombre de evento: "+obj.getNombre()+
									"\n Identificador del evento: "+obj.getId()+
									"\n Precio del evento: "+obj.getPrecio()+
									"\n Lugar del evento: "+obj.getLugar()+
									"\n Latitud del evento: "+obj.getLatitud()+
									"\n Longitud del evento: "+obj.getLongitud());
		
		}
	
		//buscamos evento por nombre (ejemplo "33º Certamen Coreográfico de Madrid")
        System.out.println("\n Evento con nombre 'Taller: Animalejos Casa de Campo.'");
        for(Evento obj: eventos) {
			if(obj.getNombre().equalsIgnoreCase("Taller: Animalejos Casa de Campo.")) {
				System.out.println("\n Nombre de evento: "+obj.getNombre()+
									"\n Precio del evento: "+obj.getPrecio()+
									"\n Lugar del evento: "+obj.getLugar()+
									"\n Latitud del evento: "+obj.getLatitud()+
									"\n Longitud del evento: "+obj.getLongitud());
			}
		}
		
		
		//filtro de precio  (ejemplo precio hasta 10 euros )
		System.out.println("\n Eventos con precio menor a 10 euros");
		for(Evento obj: eventos) {
			if(obj.getPrecio() < 15.0) {
				System.out.println("\n Nombre de evento: "+obj.getNombre()+
									"\n Identificador del evento: "+obj.getId()+
									"\n Precio del evento: "+obj.getPrecio()+
									"\n Lugar del evento: "+obj.getLugar()+
									"\n Latitud del evento: "+obj.getLatitud()+
									"\n Longitud del evento: "+obj.getLongitud());
			}
		}

	}
	
	//metodo para extraer el precio
	public static String encuentraPrecio(String str) {
		String ret;
		Pattern p = Pattern.compile(" \\d+ ");
		Matcher m = p.matcher(str);

        
        if (m.find()) {
            System.out.println(m.group(0)); // primer precio
            ret=m.group(0);
        }else {
        	ret="0";
        }
        return ret;
	}

}