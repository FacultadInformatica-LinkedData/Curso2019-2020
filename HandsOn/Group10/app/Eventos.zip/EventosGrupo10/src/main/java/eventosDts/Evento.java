package eventosDts;

public class Evento {

	private int id;
	private String nombre;
	private Double precio;
	private Double latitud;
	private Double longitud;
	private String lugar;
	
	//constructor valores por defecto
	public Evento() {
		this.precio=0.0;
		this.nombre="sinNombre";
		this.latitud=0.0;
		this.longitud=0.0;
		this.lugar="madrid";
	}
	
	public String getLugar() {
		return lugar;
	}
	public void setLugar(String lugar) {
		this.lugar = lugar;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public double getPrecio() {
		return precio;
	}
	public void setPrecio(double precio) {
		this.precio = precio;
	}
	public Double getLatitud() {
		return latitud;
	}
	public void setLatitud(Double latitud) {
		this.latitud = latitud;
	}
	public Double getLongitud() {
		return longitud;
	}
	public void setLongitud(Double longitud) {
		this.longitud = longitud;
	}
	
	
}
